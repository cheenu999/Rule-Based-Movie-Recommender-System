package MovieRecommender;

import MovieRecommender.Controller.MenuController;

/**
 * Main entry point for the Movie Manager CLI application.
 * This class initializes the application and starts the menu controller.
 */
public class App {
    /**
     * Main method that initializes the application.
     * 
     * @param args Command line arguments (not used)
     */
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("   Rule Based Movie Recommender System ");
        System.out.println("========================================\n");

        // Initialize and start the menu controller
        MenuController menuController = new MenuController();
        menuController.start();
    }
}