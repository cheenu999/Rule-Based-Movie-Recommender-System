package MovieRecommender.Controller;

import MovieRecommender.Service.AdminService;
import MovieRecommender.Service.UserService;
import MovieRecommender.Service.Impl.AdminServiceImpl;
import MovieRecommender.Service.Impl.UserServiceImpl;

import java.util.Scanner;

/**
 * Controller class for handling menu navigation and user interactions.
 * Manages the main menu, user login, admin login, and respective menu flows.
 */
public class MenuController {
    private Scanner scanner;
    private AdminService adminService;
    private UserService userService;

    /**
     * Constructor that initializes dependencies.
     */
    public MenuController() {
        this.scanner = new Scanner(System.in);
        this.adminService = new AdminServiceImpl();
        this.userService = new UserServiceImpl();
    }

    /**
     * Starts the application by displaying the main menu.
     */
    public void start() {
        showMainMenu();
    }

    /**
     * Displays the main menu and handles user selection.
     * Provides options for User login, Admin login, and Exit.
     */
    private void showMainMenu() {
        while (true) {
            System.out.println("\n--- MAIN MENU ---");
            System.out.println("1. User Login");
            System.out.println("2. Admin Login");
            System.out.println("3. Exit");
            System.out.print("\nEnter your choice: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    handleUserLogin();
                    break;
                case 2:
                    handleAdminLogin();
                    break;
                case 3:
                    System.out.println("\nThank you for using Rule Based Movie Recommender System. Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("\nInvalid choice! Please enter 1, 2, or 3.");
            }
        }
    }

    /**
     * Handles user login process.
     * Prompts for username and password, validates credentials, and shows user menu if successful.
     */
    private void handleUserLogin() {
        int userId = userService.login(scanner);
        
        if (userId > 0) {
            userService.showUserMenu(scanner, userId);
        }
        // If login fails, loop back to main menu
    }

    /**
     * Handles admin login process.
     * Prompts for username and password, validates credentials, and shows admin menu if successful.
     */
    private void handleAdminLogin() {
        int adminId = adminService.login(scanner);
        
        if (adminId > 0) {
            adminService.showAdminMenu(scanner);
        }
        // If login fails, loop back to main menu
    }

    /**
     * Helper method to safely read integer input from the user.
     * Handles invalid input and prompts for re-entry.
     * 
     * @return The integer value entered by the user
     */
    private int getIntInput() {
        while (true) {
            try {
                String input = scanner.nextLine().trim();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Please enter a number: ");
            }
        }
    }
}


