package MovieRecommender.DAO;

import MovieRecommender.Model.Watchlist;
import java.util.List;

/**
 * Data Access Object interface for Watchlist operations.
 * Defines the contract for database operations related to watchlists.
 */
public interface WatchlistDAO {
    /**
     * Creates a new watchlist entry in the database.
     * 
     * @param watchlist The watchlist object to be created
     * @return true if watchlist entry was created successfully, false otherwise
     */
    boolean create(Watchlist watchlist);

    /**
     * Retrieves a watchlist entry by movie ID and user ID.
     * 
     * @param movieId The ID of the movie
     * @param userId The ID of the user
     * @return Watchlist object if found, null otherwise
     */
    Watchlist read(int movieId, int userId);

    /**
     * Updates watchlist information in the database.
     * 
     * @param movieId The ID of the movie
     * @param userId The ID of the user
     * @param watchlist The watchlist object containing updated values
     * @return true if watchlist was updated successfully, false otherwise
     */
    boolean update(int movieId, int userId, Watchlist watchlist);

    /**
     * Deletes a watchlist entry from the database.
     * 
     * @param movieId The ID of the movie
     * @param userId The ID of the user
     * @return true if watchlist entry was deleted successfully, false otherwise
     */
    boolean delete(int movieId, int userId);

    /**
     * Retrieves all watchlist entries for a specific user.
     * 
     * @param userId The ID of the user
     * @return List of all watchlist entries for the user
     */
    List<Watchlist> getByUserId(int userId);

    /**
     * Retrieves all watchlist entries from the database.
     * 
     * @return List of all watchlist entries
     */
    List<Watchlist> getAll();
}

