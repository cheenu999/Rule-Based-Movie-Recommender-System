package MovieRecommender.DAO;

import MovieRecommender.Model.Admin;
import java.util.List;

/**
 * Data Access Object interface for Admin operations.
 * Defines the contract for database operations related to admins.
 */
public interface AdminDAO {
    /**
     * Creates a new admin in the database.
     * 
     * @param admin The admin object to be created
     * @return true if admin was created successfully, false otherwise
     */
    boolean create(Admin admin);

    /**
     * Retrieves an admin by ID.
     * 
     * @param adminId The ID of the admin to retrieve
     * @return Admin object if found, null otherwise
     */
    Admin read(int adminId);

    /**
     * Updates admin information in the database.
     * 
     * @param adminId The ID of the admin to update
     * @param admin The admin object containing updated values
     * @return true if admin was updated successfully, false otherwise
     */
    boolean update(int adminId, Admin admin);

    /**
     * Deletes an admin from the database by ID.
     * 
     * @param adminId The ID of the admin to delete
     * @return true if admin was deleted successfully, false otherwise
     */
    boolean delete(int adminId);

    /**
     * Retrieves all admins from the database.
     * 
     * @return List of all admins
     */
    List<Admin> getAll();

    /**
     * Authenticates an admin by checking username and password.
     * 
     * @param username The admin username
     * @param password The admin password
     * @return Admin ID if authentication is successful, -1 otherwise
     */
    int authenticate(String username, String password);
}

