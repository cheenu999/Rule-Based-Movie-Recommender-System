package MovieRecommender.DAO;

import MovieRecommender.Model.Rating;
import java.util.List;

/**
 * Data Access Object interface for Rating operations.
 * Defines the contract for database operations related to ratings.
 */
public interface RatingDAO {
    /**
     * Creates a new rating in the database.
     * 
     * @param rating The rating object to be created
     * @return true if rating was created successfully, false otherwise
     */
    boolean create(Rating rating);

    /**
     * Retrieves a rating by ID.
     * 
     * @param ratingId The ID of the rating to retrieve
     * @return Rating object if found, null otherwise
     */
    Rating read(int ratingId);

    /**
     * Updates rating information in the database.
     * 
     * @param ratingId The ID of the rating to update
     * @param rating The rating object containing updated values
     * @return true if rating was updated successfully, false otherwise
     */
    boolean update(int ratingId, Rating rating);

    /**
     * Deletes a rating from the database by ID.
     * 
     * @param ratingId The ID of the rating to delete
     * @return true if rating was deleted successfully, false otherwise
     */
    boolean delete(int ratingId);

    /**
     * Retrieves all ratings from the database.
     * 
     * @return List of all ratings
     */
    List<Rating> getAll();

    /**
     * Retrieves a rating by user ID and movie ID.
     * 
     * @param userId The ID of the user
     * @param movieId The ID of the movie
     * @return Rating object if found, null otherwise
     */
    Rating getByUserAndMovie(int userId, int movieId);

    /**
     * Adds or updates a rating for a movie by a user.
     * 
     * @param userId The ID of the user giving the rating
     * @param movieId The ID of the movie being rated
     * @param ratingValue The rating value (typically 1-5)
     * @param review Optional review text
     * @return true if rating was added/updated successfully, false otherwise
     */
    boolean addOrUpdateRating(int userId, int movieId, double ratingValue, String review);
}

