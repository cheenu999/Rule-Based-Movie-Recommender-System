package MovieRecommender.DAO;

import MovieRecommender.Model.User;
import java.util.List;

/**
 * Data Access Object interface for User operations.
 * Defines the contract for database operations related to users and authentication.
 */
public interface UserDAO {
    /**
     * Creates a new user in the database.
     * 
     * @param user The user object to be created
     * @return true if user was created successfully, false otherwise
     */
    boolean create(User user);

    /**
     * Retrieves a user by ID.
     * 
     * @param userId The ID of the user to retrieve
     * @return User object if found, null otherwise
     */
    User read(int userId);

    /**
     * Updates user information in the database.
     * 
     * @param userId The ID of the user to update
     * @param user The user object containing updated values
     * @return true if user was updated successfully, false otherwise
     */
    boolean update(int userId, User user);

    /**
     * Deletes a user from the database by ID.
     * 
     * @param userId The ID of the user to delete
     * @return true if user was deleted successfully, false otherwise
     */
    boolean delete(int userId);

    /**
     * Retrieves all users from the database.
     * 
     * @return List of all users
     */
    List<User> getAll();

    /**
     * Authenticates a user by checking username and password.
     * 
     * @param username The user username
     * @param password The user password
     * @return User ID if authentication is successful, -1 otherwise
     */
    int authenticateUser(String username, String password);

    /**
     * Authenticates an admin user by checking username and password.
     * 
     * @param username The admin username
     * @param password The admin password
     * @return Admin ID if authentication is successful, -1 otherwise
     */
    int authenticateAdmin(String username, String password);

    /**
     * Adds or updates a rating for a movie by a user.
     * 
     * @param userId The ID of the user giving the rating
     * @param movieId The ID of the movie being rated
     * @param ratingValue The rating value (typically 1-5)
     * @param review Optional review text
     * @return true if rating was added/updated successfully, false otherwise
     */
    boolean addOrUpdateRating(int userId, int movieId, double ratingValue, String review);

    /**
     * Gets the rating given by a specific user for a specific movie.
     * 
     * @param userId The ID of the user
     * @param movieId The ID of the movie
     * @return The rating value, or -1 if not found
     */
    double getUserRating(int userId, int movieId);
}


