package MovieRecommender.DAO.Impl;

import MovieRecommender.DAO.AdminDAO;
import MovieRecommender.Model.Admin;
import MovieRecommender.Util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of AdminDAO interface.
 * Handles all database operations related to admins.
 */
public class AdminDAOImpl implements AdminDAO {
    private Connection connection;

    /**
     * Constructor that initializes the database connection.
     */
    public AdminDAOImpl() {
        try {
            this.connection = DatabaseUtil.getConnection();
        } catch (SQLException e) {
            System.err.println("Error initializing AdminDAOImpl: " + e.getMessage());
        }
    }

    @Override
    public boolean create(Admin admin) {
        String sql = "INSERT INTO Admin (username, password, email, full_name, role) VALUES (?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, admin.getUsername());
            pstmt.setString(2, admin.getPassword());
            pstmt.setString(3, admin.getEmail());
            pstmt.setString(4, admin.getFullName());
            pstmt.setString(5, admin.getRole() != null ? admin.getRole() : "admin");
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error creating admin: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Admin read(int adminId) {
        String sql = "SELECT * FROM Admin WHERE admin_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, adminId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Admin(
                        rs.getInt("admin_id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("email"),
                        rs.getString("full_name"),
                        rs.getString("role"),
                        rs.getTimestamp("created_at") != null ? rs.getTimestamp("created_at").toString() : null
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error reading admin: " + e.getMessage());
        }
        
        return null;
    }

    @Override
    public boolean update(int adminId, Admin admin) {
        String sql = "UPDATE Admin SET username = ?, password = ?, email = ?, full_name = ?, role = ? WHERE admin_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, admin.getUsername());
            pstmt.setString(2, admin.getPassword());
            pstmt.setString(3, admin.getEmail());
            pstmt.setString(4, admin.getFullName());
            pstmt.setString(5, admin.getRole());
            pstmt.setInt(6, adminId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating admin: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int adminId) {
        String sql = "DELETE FROM Admin WHERE admin_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, adminId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting admin: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<Admin> getAll() {
        List<Admin> admins = new ArrayList<>();
        String sql = "SELECT * FROM Admin ORDER BY admin_id";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Admin admin = new Admin(
                    rs.getInt("admin_id"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("email"),
                    rs.getString("full_name"),
                    rs.getString("role"),
                    rs.getTimestamp("created_at") != null ? rs.getTimestamp("created_at").toString() : null
                );
                admins.add(admin);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving admins: " + e.getMessage());
        }
        
        return admins;
    }

    @Override
    public int authenticate(String username, String password) {
        String sql = "SELECT admin_id FROM Admin WHERE username = ? AND password = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("admin_id");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error authenticating admin: " + e.getMessage());
        }
        
        return -1;
    }
}

