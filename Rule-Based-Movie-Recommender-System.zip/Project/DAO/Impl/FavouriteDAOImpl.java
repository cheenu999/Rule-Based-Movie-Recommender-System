package MovieRecommender.DAO.Impl;

import MovieRecommender.DAO.FavouriteDAO;
import MovieRecommender.Model.Favourite;
import MovieRecommender.Util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of FavouriteDAO interface.
 * Handles all database operations related to favourites.
 */
public class FavouriteDAOImpl implements FavouriteDAO {
    private Connection connection;

    /**
     * Constructor that initializes the database connection.
     */
    public FavouriteDAOImpl() {
        try {
            this.connection = DatabaseUtil.getConnection();
        } catch (SQLException e) {
            System.err.println("Error initializing FavouriteDAOImpl: " + e.getMessage());
        }
    }

    @Override
    public boolean create(Favourite favourite) {
        String sql = "INSERT INTO Favourites (movie_id, title, genre, average_rating, user_id) VALUES (?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, favourite.getMovieId());
            pstmt.setString(2, favourite.getTitle());
            pstmt.setString(3, favourite.getGenre());
            pstmt.setDouble(4, favourite.getAverageRating());
            pstmt.setInt(5, favourite.getUserId());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error creating favourite: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Favourite read(int movieId, int userId) {
        String sql = "SELECT * FROM Favourites WHERE movie_id = ? AND user_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, movieId);
            pstmt.setInt(2, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Favourite(
                        rs.getInt("movie_id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getDouble("average_rating"),
                        rs.getInt("user_id")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error reading favourite: " + e.getMessage());
        }
        
        return null;
    }

    @Override
    public boolean update(int movieId, int userId, Favourite favourite) {
        String sql = "UPDATE Favourites SET title = ?, genre = ?, average_rating = ? WHERE movie_id = ? AND user_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, favourite.getTitle());
            pstmt.setString(2, favourite.getGenre());
            pstmt.setDouble(3, favourite.getAverageRating());
            pstmt.setInt(4, movieId);
            pstmt.setInt(5, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating favourite: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int movieId, int userId) {
        String sql = "DELETE FROM Favourites WHERE movie_id = ? AND user_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, movieId);
            pstmt.setInt(2, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting favourite: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<Favourite> getByUserId(int userId) {
        List<Favourite> favourites = new ArrayList<>();
        String sql = "SELECT * FROM Favourites WHERE user_id = ? ORDER BY movie_id";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Favourite favourite = new Favourite(
                        rs.getInt("movie_id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getDouble("average_rating"),
                        rs.getInt("user_id")
                    );
                    favourites.add(favourite);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving favourites by user: " + e.getMessage());
        }
        
        return favourites;
    }

    @Override
    public List<Favourite> getAll() {
        List<Favourite> favourites = new ArrayList<>();
        String sql = "SELECT * FROM Favourites ORDER BY user_id, movie_id";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Favourite favourite = new Favourite(
                    rs.getInt("movie_id"),
                    rs.getString("title"),
                    rs.getString("genre"),
                    rs.getDouble("average_rating"),
                    rs.getInt("user_id")
                );
                favourites.add(favourite);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving favourites: " + e.getMessage());
        }
        
        return favourites;
    }
}

