package MovieRecommender.DAO.Impl;

import MovieRecommender.DAO.MovieDAO;
import MovieRecommender.Model.Movie;
import MovieRecommender.Util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of MovieDAO interface.
 * Handles all database operations related to movies.
 */
public class MovieDAOImpl implements MovieDAO {
    private Connection connection;

    /**
     * Constructor that initializes the database connection.
     */
    public MovieDAOImpl() {
        try {
            this.connection = DatabaseUtil.getConnection();
        } catch (SQLException e) {
            System.err.println("Error initializing MovieDAOImpl: " + e.getMessage());
        }
    }

    @Override
    public boolean addMovie(Movie movie) {
        String sql = "INSERT INTO Movies (title, genre, director, release_year, average_rating) VALUES (?, ?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, movie.getTitle());
            pstmt.setString(2, movie.getGenre());
            pstmt.setString(3, movie.getDirector());
            pstmt.setInt(4, movie.getReleaseYear());
            pstmt.setDouble(5, movie.getAverageRating());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error adding movie: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteMovie(int movieId) {
        String sql = "DELETE FROM Movies WHERE movie_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, movieId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting movie: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean updateMovie(int movieId, Movie movie) {
        StringBuilder sql = new StringBuilder("UPDATE Movies SET ");
        List<String> updates = new ArrayList<>();
        List<Object> params = new ArrayList<>();
        
        if (movie.getTitle() != null && !movie.getTitle().trim().isEmpty()) {
            updates.add("title = ?");
            params.add(movie.getTitle());
        }
        if (movie.getGenre() != null && !movie.getGenre().trim().isEmpty()) {
            updates.add("genre = ?");
            params.add(movie.getGenre());
        }
        if (movie.getDirector() != null && !movie.getDirector().trim().isEmpty()) {
            updates.add("director = ?");
            params.add(movie.getDirector());
        }
        if (movie.getReleaseYear() > 0) {
            updates.add("release_year = ?");
            params.add(movie.getReleaseYear());
        }
        if (movie.getAverageRating() >= 0) {
            updates.add("average_rating = ?");
            params.add(movie.getAverageRating());
        }
        
        if (updates.isEmpty()) {
            return false;
        }
        
        sql.append(String.join(", ", updates));
        sql.append(" WHERE movie_id = ?");
        params.add(movieId);
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                Object param = params.get(i);
                if (param instanceof String) {
                    pstmt.setString(i + 1, (String) param);
                } else if (param instanceof Integer) {
                    pstmt.setInt(i + 1, (Integer) param);
                } else if (param instanceof Double) {
                    pstmt.setDouble(i + 1, (Double) param);
                }
            }
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating movie: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<Movie> getAllMovies() {
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT * FROM Movies ORDER BY movie_id";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Movie movie = new Movie(
                    rs.getInt("movie_id"),
                    rs.getString("title"),
                    rs.getString("genre"),
                    rs.getString("director"),
                    rs.getInt("release_year"),
                    rs.getDouble("average_rating")
                );
                movies.add(movie);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving movies: " + e.getMessage());
        }
        
        return movies;
    }

    @Override
    public List<Movie> getMoviesByGenre(String genre) {
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT * FROM Movies WHERE genre LIKE ? ORDER BY average_rating DESC";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, "%" + genre + "%");
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Movie movie = new Movie(
                        rs.getInt("movie_id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getString("director"),
                        rs.getInt("release_year"),
                        rs.getDouble("average_rating")
                    );
                    movies.add(movie);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving movies by genre: " + e.getMessage());
        }
        
        return movies;
    }

    @Override
    public Movie getMovieById(int movieId) {
        String sql = "SELECT * FROM Movies WHERE movie_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, movieId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Movie(
                        rs.getInt("movie_id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getString("director"),
                        rs.getInt("release_year"),
                        rs.getDouble("average_rating")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving movie: " + e.getMessage());
        }
        
        return null;
    }

    @Override
    public boolean updateAverageRating(int movieId) {
        String sql = "UPDATE Movies SET average_rating = " +
                     "(SELECT AVG(rating_value) FROM Ratings WHERE movie_id = ?) " +
                     "WHERE movie_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, movieId);
            pstmt.setInt(2, movieId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating average rating: " + e.getMessage());
            return false;
        }
    }
}


