package MovieRecommender.DAO.Impl;

import MovieRecommender.DAO.RatingDAO;
import MovieRecommender.Model.Rating;
import MovieRecommender.Util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of RatingDAO interface.
 * Handles all database operations related to ratings.
 */
public class RatingDAOImpl implements RatingDAO {
    private Connection connection;

    /**
     * Constructor that initializes the database connection.
     */
    public RatingDAOImpl() {
        try {
            this.connection = DatabaseUtil.getConnection();
        } catch (SQLException e) {
            System.err.println("Error initializing RatingDAOImpl: " + e.getMessage());
        }
    }

    @Override
    public boolean create(Rating rating) {
        String sql = "INSERT INTO Ratings (user_id, movie_id, rating_value, review) VALUES (?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, rating.getUserId());
            pstmt.setInt(2, rating.getMovieId());
            pstmt.setDouble(3, rating.getRatingValue());
            pstmt.setString(4, rating.getReview());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error creating rating: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Rating read(int ratingId) {
        String sql = "SELECT * FROM Ratings WHERE rating_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, ratingId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Rating(
                        rs.getInt("rating_id"),
                        rs.getInt("user_id"),
                        rs.getInt("movie_id"),
                        rs.getDouble("rating_value"),
                        rs.getString("review")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error reading rating: " + e.getMessage());
        }
        
        return null;
    }

    @Override
    public boolean update(int ratingId, Rating rating) {
        String sql = "UPDATE Ratings SET user_id = ?, movie_id = ?, rating_value = ?, review = ? WHERE rating_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, rating.getUserId());
            pstmt.setInt(2, rating.getMovieId());
            pstmt.setDouble(3, rating.getRatingValue());
            pstmt.setString(4, rating.getReview());
            pstmt.setInt(5, ratingId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating rating: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int ratingId) {
        String sql = "DELETE FROM Ratings WHERE rating_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, ratingId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting rating: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<Rating> getAll() {
        List<Rating> ratings = new ArrayList<>();
        String sql = "SELECT * FROM Ratings ORDER BY rating_id";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Rating rating = new Rating(
                    rs.getInt("rating_id"),
                    rs.getInt("user_id"),
                    rs.getInt("movie_id"),
                    rs.getDouble("rating_value"),
                    rs.getString("review")
                );
                ratings.add(rating);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving ratings: " + e.getMessage());
        }
        
        return ratings;
    }

    @Override
    public Rating getByUserAndMovie(int userId, int movieId) {
        String sql = "SELECT * FROM Ratings WHERE user_id = ? AND movie_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setInt(2, movieId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Rating(
                        rs.getInt("rating_id"),
                        rs.getInt("user_id"),
                        rs.getInt("movie_id"),
                        rs.getDouble("rating_value"),
                        rs.getString("review")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving rating by user and movie: " + e.getMessage());
        }
        
        return null;
    }

    @Override
    public boolean addOrUpdateRating(int userId, int movieId, double ratingValue, String review) {
        Rating existingRating = getByUserAndMovie(userId, movieId);
        
        if (existingRating != null) {
            // Update existing rating
            existingRating.setRatingValue(ratingValue);
            existingRating.setReview(review);
            return update(existingRating.getRatingId(), existingRating);
        } else {
            // Create new rating
            Rating newRating = new Rating(0, userId, movieId, ratingValue, review);
            return create(newRating);
        }
    }
}

