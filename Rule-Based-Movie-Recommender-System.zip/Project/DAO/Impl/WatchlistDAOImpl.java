package MovieRecommender.DAO.Impl;

import MovieRecommender.DAO.WatchlistDAO;
import MovieRecommender.Model.Watchlist;
import MovieRecommender.Util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of WatchlistDAO interface.
 * Handles all database operations related to watchlists.
 */
public class WatchlistDAOImpl implements WatchlistDAO {
    private Connection connection;

    /**
     * Constructor that initializes the database connection.
     */
    public WatchlistDAOImpl() {
        try {
            this.connection = DatabaseUtil.getConnection();
        } catch (SQLException e) {
            System.err.println("Error initializing WatchlistDAOImpl: " + e.getMessage());
        }
    }

    @Override
    public boolean create(Watchlist watchlist) {
        String sql = "INSERT INTO Watchlist (movie_id, title, genre, user_id) VALUES (?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, watchlist.getMovieId());
            pstmt.setString(2, watchlist.getTitle());
            pstmt.setString(3, watchlist.getGenre());
            pstmt.setInt(4, watchlist.getUserId());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error creating watchlist entry: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Watchlist read(int movieId, int userId) {
        String sql = "SELECT * FROM Watchlist WHERE movie_id = ? AND user_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, movieId);
            pstmt.setInt(2, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Watchlist(
                        rs.getInt("movie_id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getInt("user_id")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error reading watchlist entry: " + e.getMessage());
        }
        
        return null;
    }

    @Override
    public boolean update(int movieId, int userId, Watchlist watchlist) {
        String sql = "UPDATE Watchlist SET title = ?, genre = ? WHERE movie_id = ? AND user_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, watchlist.getTitle());
            pstmt.setString(2, watchlist.getGenre());
            pstmt.setInt(3, movieId);
            pstmt.setInt(4, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating watchlist entry: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int movieId, int userId) {
        String sql = "DELETE FROM Watchlist WHERE movie_id = ? AND user_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, movieId);
            pstmt.setInt(2, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting watchlist entry: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<Watchlist> getByUserId(int userId) {
        List<Watchlist> watchlists = new ArrayList<>();
        String sql = "SELECT * FROM Watchlist WHERE user_id = ? ORDER BY movie_id";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Watchlist watchlist = new Watchlist(
                        rs.getInt("movie_id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getInt("user_id")
                    );
                    watchlists.add(watchlist);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving watchlist by user: " + e.getMessage());
        }
        
        return watchlists;
    }

    @Override
    public List<Watchlist> getAll() {
        List<Watchlist> watchlists = new ArrayList<>();
        String sql = "SELECT * FROM Watchlist ORDER BY user_id, movie_id";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Watchlist watchlist = new Watchlist(
                    rs.getInt("movie_id"),
                    rs.getString("title"),
                    rs.getString("genre"),
                    rs.getInt("user_id")
                );
                watchlists.add(watchlist);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving watchlists: " + e.getMessage());
        }
        
        return watchlists;
    }
}

