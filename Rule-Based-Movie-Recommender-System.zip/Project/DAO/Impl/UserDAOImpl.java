package MovieRecommender.DAO.Impl;

import MovieRecommender.DAO.UserDAO;
import MovieRecommender.Model.User;
import MovieRecommender.Util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of UserDAO interface.
 * Handles all database operations related to users, authentication, and ratings.
 */
public class UserDAOImpl implements UserDAO {
    private Connection connection;

    /**
     * Constructor that initializes the database connection.
     */
    public UserDAOImpl() {
        try {
            this.connection = DatabaseUtil.getConnection();
        } catch (SQLException e) {
            System.err.println("Error initializing UserDAOImpl: " + e.getMessage());
        }
    }

    @Override
    public boolean create(User user) {
        String sql = "INSERT INTO Users (username, password, email) VALUES (?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getEmail());
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error creating user: " + e.getMessage());
            return false;
        }
    }

    @Override
    public User read(int userId) {
        String sql = "SELECT * FROM Users WHERE user_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new User(
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("email"),
                        rs.getTimestamp("registration_date") != null ? rs.getTimestamp("registration_date").toString() : null
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error reading user: " + e.getMessage());
        }
        
        return null;
    }

    @Override
    public boolean update(int userId, User user) {
        String sql = "UPDATE Users SET username = ?, password = ?, email = ? WHERE user_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getEmail());
            pstmt.setInt(4, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating user: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int userId) {
        String sql = "DELETE FROM Users WHERE user_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting user: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<User> getAll() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM Users ORDER BY user_id";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                User user = new User(
                    rs.getInt("user_id"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("email"),
                    rs.getTimestamp("registration_date") != null ? rs.getTimestamp("registration_date").toString() : null
                );
                users.add(user);
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving users: " + e.getMessage());
        }
        
        return users;
    }

    @Override
    public int authenticateUser(String username, String password) {
        String sql = "SELECT user_id FROM Users WHERE username = ? AND password = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("user_id");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error authenticating user: " + e.getMessage());
        }
        
        return -1;
    }

    @Override
    public int authenticateAdmin(String username, String password) {
        String sql = "SELECT admin_id FROM Admin WHERE username = ? AND password = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("admin_id");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error authenticating admin: " + e.getMessage());
        }
        
        return -1;
    }

    @Override
    public boolean addOrUpdateRating(int userId, int movieId, double ratingValue, String review) {
        // Check if rating already exists
        if (ratingExists(userId, movieId)) {
            return updateRating(userId, movieId, ratingValue, review);
        } else {
            return addRating(userId, movieId, ratingValue, review);
        }
    }

    /**
     * Checks if a rating already exists for a user and movie combination.
     * 
     * @param userId The ID of the user
     * @param movieId The ID of the movie
     * @return true if rating exists, false otherwise
     */
    private boolean ratingExists(int userId, int movieId) {
        String sql = "SELECT COUNT(*) FROM Ratings WHERE user_id = ? AND movie_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setInt(2, movieId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error checking rating existence: " + e.getMessage());
        }
        
        return false;
    }

    /**
     * Adds a new rating to the database.
     * 
     * @param userId The ID of the user giving the rating
     * @param movieId The ID of the movie being rated
     * @param ratingValue The rating value
     * @param review Optional review text
     * @return true if rating was added successfully, false otherwise
     */
    private boolean addRating(int userId, int movieId, double ratingValue, String review) {
        String sql = "INSERT INTO Ratings (user_id, movie_id, rating_value, review) VALUES (?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setInt(2, movieId);
            pstmt.setDouble(3, ratingValue);
            pstmt.setString(4, review);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error adding rating: " + e.getMessage());
            return false;
        }
    }

    /**
     * Updates an existing rating in the database.
     * 
     * @param userId The ID of the user
     * @param movieId The ID of the movie
     * @param ratingValue The new rating value
     * @param review The new review text
     * @return true if rating was updated successfully, false otherwise
     */
    private boolean updateRating(int userId, int movieId, double ratingValue, String review) {
        String sql = "UPDATE Ratings SET rating_value = ?, review = ? WHERE user_id = ? AND movie_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setDouble(1, ratingValue);
            pstmt.setString(2, review);
            pstmt.setInt(3, userId);
            pstmt.setInt(4, movieId);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating rating: " + e.getMessage());
            return false;
        }
    }

    @Override
    public double getUserRating(int userId, int movieId) {
        String sql = "SELECT rating_value FROM Ratings WHERE user_id = ? AND movie_id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setInt(2, movieId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("rating_value");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving user rating: " + e.getMessage());
        }
        
        return -1;
    }
}


