package MovieRecommender.DAO;

import MovieRecommender.Model.Favourite;
import java.util.List;

/**
 * Data Access Object interface for Favourite operations.
 * Defines the contract for database operations related to favourites.
 */
public interface FavouriteDAO {
    /**
     * Creates a new favourite in the database.
     * 
     * @param favourite The favourite object to be created
     * @return true if favourite was created successfully, false otherwise
     */
    boolean create(Favourite favourite);

    /**
     * Retrieves a favourite by movie ID and user ID.
     * 
     * @param movieId The ID of the movie
     * @param userId The ID of the user
     * @return Favourite object if found, null otherwise
     */
    Favourite read(int movieId, int userId);

    /**
     * Updates favourite information in the database.
     * 
     * @param movieId The ID of the movie
     * @param userId The ID of the user
     * @param favourite The favourite object containing updated values
     * @return true if favourite was updated successfully, false otherwise
     */
    boolean update(int movieId, int userId, Favourite favourite);

    /**
     * Deletes a favourite from the database.
     * 
     * @param movieId The ID of the movie
     * @param userId The ID of the user
     * @return true if favourite was deleted successfully, false otherwise
     */
    boolean delete(int movieId, int userId);

    /**
     * Retrieves all favourites for a specific user.
     * 
     * @param userId The ID of the user
     * @return List of all favourites for the user
     */
    List<Favourite> getByUserId(int userId);

    /**
     * Retrieves all favourites from the database.
     * 
     * @return List of all favourites
     */
    List<Favourite> getAll();
}

