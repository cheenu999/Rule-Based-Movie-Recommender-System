package MovieRecommender.DAO;

import MovieRecommender.Model.Movie;
import java.util.List;

/**
 * Data Access Object interface for Movie operations.
 * Defines the contract for database operations related to movies.
 */
public interface MovieDAO {
    /**
     * Adds a new movie to the database.
     * 
     * @param movie The movie object to be added
     * @return true if movie was added successfully, false otherwise
     */
    boolean addMovie(Movie movie);

    /**
     * Deletes a movie from the database by its ID.
     * 
     * @param movieId The ID of the movie to delete
     * @return true if movie was deleted successfully, false otherwise
     */
    boolean deleteMovie(int movieId);

    /**
     * Updates movie information in the database.
     * 
     * @param movieId The ID of the movie to update
     * @param movie The movie object containing updated values
     * @return true if movie was updated successfully, false otherwise
     */
    boolean updateMovie(int movieId, Movie movie);

    /**
     * Retrieves all movies from the database.
     * 
     * @return List of all movies
     */
    List<Movie> getAllMovies();

    /**
     * Retrieves movies by genre.
     * 
     * @param genre The genre to search for
     * @return List of movies matching the genre
     */
    List<Movie> getMoviesByGenre(String genre);

    /**
     * Retrieves a movie by its ID.
     * 
     * @param movieId The ID of the movie to retrieve
     * @return Movie object if found, null otherwise
     */
    Movie getMovieById(int movieId);

    /**
     * Updates the average rating of a movie based on all user ratings.
     * 
     * @param movieId The ID of the movie to update
     * @return true if update was successful, false otherwise
     */
    boolean updateAverageRating(int movieId);
}



