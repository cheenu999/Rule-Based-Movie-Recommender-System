package MovieRecommender.Service;

import java.util.Scanner;

/**
 * Service interface for favourite-related business logic.
 * Defines operations for managing user favourites.
 */
public interface FavouriteService {
    /**
     * Adds a movie to user's favourites.
     * 
     * @param scanner Scanner object for user input
     * @param userId The ID of the user
     */
    void addFavourite(Scanner scanner, int userId);

    /**
     * Removes a movie from user's favourites.
     * 
     * @param scanner Scanner object for user input
     * @param userId The ID of the user
     */
    void removeFavourite(Scanner scanner, int userId);

    /**
     * Displays all favourites for a user.
     * 
     * @param userId The ID of the user
     */
    void viewFavourites(int userId);
}

