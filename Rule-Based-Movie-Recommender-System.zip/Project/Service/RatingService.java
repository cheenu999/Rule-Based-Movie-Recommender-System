package MovieRecommender.Service;

import java.util.Scanner;

/**
 * Service interface for rating-related business logic.
 * Defines operations for managing movie ratings.
 */
public interface RatingService {
    /**
     * Allows a user to rate a movie.
     * 
     * @param scanner Scanner object for user input
     * @param userId The ID of the user rating the movie
     */
    void rateMovie(Scanner scanner, int userId);
}

