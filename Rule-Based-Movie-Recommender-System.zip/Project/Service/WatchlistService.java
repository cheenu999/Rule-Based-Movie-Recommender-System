package MovieRecommender.Service;

import java.util.Scanner;

/**
 * Service interface for watchlist-related business logic.
 * Defines operations for managing user watchlists.
 */
public interface WatchlistService {
    /**
     * Adds a movie to user's watchlist.
     * 
     * @param scanner Scanner object for user input
     * @param userId The ID of the user
     */
    void addToWatchlist(Scanner scanner, int userId);

    /**
     * Removes a movie from user's watchlist.
     * 
     * @param scanner Scanner object for user input
     * @param userId The ID of the user
     */
    void removeFromWatchlist(Scanner scanner, int userId);

    /**
     * Displays all movies in user's watchlist.
     * 
     * @param userId The ID of the user
     */
    void viewWatchlist(int userId);
}

