package MovieRecommender.Service.Impl;

import MovieRecommender.DAO.UserDAO;
import MovieRecommender.DAO.Impl.UserDAOImpl;
import MovieRecommender.Service.FavouriteService;
import MovieRecommender.Service.MovieService;
import MovieRecommender.Service.RatingService;
import MovieRecommender.Service.UserService;
import MovieRecommender.Service.WatchlistService;

import java.util.Scanner;

/**
 * Implementation of UserService interface.
 * Handles business logic for user operations.
 */
public class UserServiceImpl implements UserService {
    private UserDAO userDAO;
    private MovieService movieService;
    private RatingService ratingService;
    private FavouriteService favouriteService;
    private WatchlistService watchlistService;

    /**
     * Constructor that initializes dependencies.
     */
    public UserServiceImpl() {
        this.userDAO = new UserDAOImpl();
        this.movieService = new MovieServiceImpl();
        this.ratingService = new RatingServiceImpl();
        this.favouriteService = new FavouriteServiceImpl();
        this.watchlistService = new WatchlistServiceImpl();
    }

    @Override
    public int login(Scanner scanner) {
        System.out.println("\n--- USER LOGIN ---");
        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter password: ");
        String password = scanner.nextLine().trim();

        int userId = userDAO.authenticateUser(username, password);
        
        if (userId > 0) {
            System.out.println("\nLogin successful! Welcome, " + username + "!");
            return userId;
        } else {
            System.out.println("\nInvalid credentials! Please try again.");
            return -1;
        }
    }

    @Override
    public void showUserMenu(Scanner scanner, int userId) {
        while (true) {
            System.out.println("\n--- USER MENU ---");
            System.out.println("1. View all movies");
            System.out.println("2. Get recommendations based on genre");
            System.out.println("3. Rate any movie");
            System.out.println("4. Build watchlist");
            System.out.println("5. Build favourites");
            System.out.println("6. Logout");
            System.out.print("\nEnter your choice: ");

            int choice = getIntInput(scanner);

            switch (choice) {
                case 1:
                    movieService.viewAllMovies();
                    break;
                case 2:
                    movieService.getRecommendations(scanner);
                    break;
                case 3:
                    ratingService.rateMovie(scanner, userId);
                    break;
                case 4:
                    showWatchlistMenu(scanner, userId);
                    break;
                case 5:
                    showFavouritesMenu(scanner, userId);
                    break;
                case 6:
                    System.out.println("\nLogged out successfully!");
                    return;
                default:
                    System.out.println("\nInvalid choice! Please enter a number between 1-6.");
            }
        }
    }

    /**
     * Shows watchlist submenu.
     */
    private void showWatchlistMenu(Scanner scanner, int userId) {
        while (true) {
            System.out.println("\n--- WATCHLIST MENU ---");
            System.out.println("1. Add movie to watchlist");
            System.out.println("2. Remove movie from watchlist");
            System.out.println("3. View my watchlist");
            System.out.println("4. Back to main menu");
            System.out.print("\nEnter your choice: ");

            int choice = getIntInput(scanner);

            switch (choice) {
                case 1:
                    watchlistService.addToWatchlist(scanner, userId);
                    break;
                case 2:
                    watchlistService.removeFromWatchlist(scanner, userId);
                    break;
                case 3:
                    watchlistService.viewWatchlist(userId);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("\nInvalid choice! Please enter a number between 1-4.");
            }
        }
    }

    /**
     * Shows favourites submenu.
     */
    private void showFavouritesMenu(Scanner scanner, int userId) {
        while (true) {
            System.out.println("\n--- FAVOURITES MENU ---");
            System.out.println("1. Add movie to favourites");
            System.out.println("2. Remove movie from favourites");
            System.out.println("3. View my favourites");
            System.out.println("4. Back to main menu");
            System.out.print("\nEnter your choice: ");

            int choice = getIntInput(scanner);

            switch (choice) {
                case 1:
                    favouriteService.addFavourite(scanner, userId);
                    break;
                case 2:
                    favouriteService.removeFavourite(scanner, userId);
                    break;
                case 3:
                    favouriteService.viewFavourites(userId);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("\nInvalid choice! Please enter a number between 1-4.");
            }
        }
    }

    /**
     * Helper method to safely read integer input.
     */
    private int getIntInput(Scanner scanner) {
        while (true) {
            try {
                String input = scanner.nextLine().trim();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Please enter a number: ");
            }
        }
    }
}

