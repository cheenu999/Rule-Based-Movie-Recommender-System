package MovieRecommender.Service.Impl;

import MovieRecommender.DAO.MovieDAO;
import MovieRecommender.DAO.RatingDAO;
import MovieRecommender.DAO.Impl.MovieDAOImpl;
import MovieRecommender.DAO.Impl.RatingDAOImpl;
import MovieRecommender.Model.Movie;
import MovieRecommender.Service.MovieService;

import java.util.List;
import java.util.Scanner;

/**
 * Implementation of MovieService interface.
 * Handles business logic for movie operations, delegating database operations to DAO layer.
 */
public class MovieServiceImpl implements MovieService {
    private MovieDAO movieDAO;
    private RatingDAO ratingDAO;

    /**
     * Constructor that initializes DAO dependencies.
     */
    public MovieServiceImpl() {
        this.movieDAO = new MovieDAOImpl();
        this.ratingDAO = new RatingDAOImpl();
    }

    @Override
    public void addMovie(Scanner scanner) {
        System.out.println("\n--- ADD NEW MOVIE ---");
        
        System.out.print("Enter movie title: ");
        String title = scanner.nextLine().trim();
        
        System.out.print("Enter genre: ");
        String genre = scanner.nextLine().trim();
        
        System.out.print("Enter director name: ");
        String director = scanner.nextLine().trim();
        
        System.out.print("Enter release year: ");
        int releaseYear = getIntInput(scanner);
        
        System.out.print("Enter initial average rating (0.0-5.0): ");
        double rating = getDoubleInput(scanner);
        
        Movie movie = new Movie(0, title, genre, director, releaseYear, rating);
        
        if (movieDAO.addMovie(movie)) {
            System.out.println("\nMovie added successfully!");
        } else {
            System.out.println("\nFailed to add movie. Please try again.");
        }
    }

    @Override
    public void deleteMovie(Scanner scanner) {
        System.out.println("\n--- DELETE MOVIE ---");
        viewAllMovies();
        
        System.out.print("\nEnter the movie ID to delete: ");
        int movieId = getIntInput(scanner);
        
        // Confirm deletion
        Movie movie = movieDAO.getMovieById(movieId);
        if (movie == null) {
            System.out.println("\nMovie not found!");
            return;
        }
        
        System.out.println("\nMovie to delete: " + movie.getTitle());
        System.out.print("Are you sure you want to delete this movie? (yes/no): ");
        String confirmation = scanner.nextLine().trim().toLowerCase();
        
        if (confirmation.equals("yes")) {
            if (movieDAO.deleteMovie(movieId)) {
                System.out.println("\nMovie deleted successfully!");
            } else {
                System.out.println("\nFailed to delete movie. Please try again.");
            }
        } else {
            System.out.println("\nDeletion cancelled.");
        }
    }

    @Override
    public void updateMovie(Scanner scanner) {
        System.out.println("\n--- UPDATE MOVIE ---");
        viewAllMovies();
        
        System.out.print("\nEnter the movie ID to update: ");
        int movieId = getIntInput(scanner);
        
        Movie existingMovie = movieDAO.getMovieById(movieId);
        if (existingMovie == null) {
            System.out.println("\nMovie not found!");
            return;
        }
        
        System.out.println("\nCurrent movie details:");
        System.out.println(existingMovie);
        System.out.println("\nEnter new values (press Enter to skip):");
        
        System.out.print("Enter new title: ");
        String title = scanner.nextLine().trim();
        
        System.out.print("Enter new genre: ");
        String genre = scanner.nextLine().trim();
        
        System.out.print("Enter new director: ");
        String director = scanner.nextLine().trim();
        
        System.out.print("Enter new release year (0 to skip): ");
        int releaseYear = getIntInput(scanner);
        
        System.out.print("Enter new average rating (-1 to skip): ");
        double rating = getDoubleInput(scanner);
        
        Movie updatedMovie = new Movie();
        updatedMovie.setTitle(title.isEmpty() ? null : title);
        updatedMovie.setGenre(genre.isEmpty() ? null : genre);
        updatedMovie.setDirector(director.isEmpty() ? null : director);
        updatedMovie.setReleaseYear(releaseYear > 0 ? releaseYear : 0);
        updatedMovie.setAverageRating(rating >= 0 ? rating : -1);
        
        if (movieDAO.updateMovie(movieId, updatedMovie)) {
            System.out.println("\nMovie updated successfully!");
        } else {
            System.out.println("\nFailed to update movie. Please try again.");
        }
    }

    @Override
    public void viewAllMovies() {
        System.out.println("\n--- ALL MOVIES ---");
        System.out.println(String.format("%-5s | %-30s | %-20s | %-20s | %-6s | %-6s",
                "ID", "Title", "Genre", "Director", "Year", "Rating"));
        System.out.println("------------------------------------------------------------------------------------------------");
        
        List<Movie> movies = movieDAO.getAllMovies();
        
        if (movies.isEmpty()) {
            System.out.println("No movies found in the database.");
        } else {
            for (Movie movie : movies) {
                System.out.println(String.format("%-5d | %-30s | %-20s | %-20s | %-6d | %-6.2f",
                        movie.getMovieId(), movie.getTitle(), movie.getGenre(),
                        movie.getDirector(), movie.getReleaseYear(), movie.getAverageRating()));
            }
        }
    }

    @Override
    public void getRecommendations(Scanner scanner) {
        System.out.println("\n--- GET MOVIE RECOMMENDATIONS ---");
        System.out.print("Enter genre(s) separated by commas (e.g., Fantasy, Adventure): ");
        String genreInput = scanner.nextLine().trim();
        
        if (genreInput.isEmpty()) {
            System.out.println("\nNo genre provided. Showing all movies sorted by rating:");
            viewAllMovies();
            return;
        }
        
        String[] genres = genreInput.split(",");
        System.out.println("\n--- RECOMMENDED MOVIES ---");
        System.out.println(String.format("%-5s | %-30s | %-20s | %-20s | %-6s | %-6s",
                "ID", "Title", "Genre", "Director", "Year", "Rating"));
        System.out.println("------------------------------------------------------------------------------------------------");
        
        boolean foundAny = false;
        
        for (String genre : genres) {
            genre = genre.trim();
            List<Movie> movies = movieDAO.getMoviesByGenre(genre);
            
            if (!movies.isEmpty()) {
                foundAny = true;
                System.out.println("\nMovies in genre: " + genre);
                for (Movie movie : movies) {
                    System.out.println(String.format("%-5d | %-30s | %-20s | %-20s | %-6d | %-6.2f",
                            movie.getMovieId(), movie.getTitle(), movie.getGenre(),
                            movie.getDirector(), movie.getReleaseYear(), movie.getAverageRating()));
                }
            }
        }
        
        if (!foundAny) {
            System.out.println("\nNo movies found for the specified genre(s).");
        }
    }

    @Override
    public void rateMovie(Scanner scanner, int userId) {
        System.out.println("\n--- RATE A MOVIE ---");
        viewAllMovies();
        
        System.out.print("\nEnter the movie ID to rate: ");
        int movieId = getIntInput(scanner);
        
        Movie movie = movieDAO.getMovieById(movieId);
        if (movie == null) {
            System.out.println("\nMovie not found!");
            return;
        }
        
        // Check if user has already rated this movie
        MovieRecommender.Model.Rating existingRating = ratingDAO.getByUserAndMovie(userId, movieId);
        if (existingRating != null) {
            System.out.println("\nYou have already rated this movie. Your current rating: " + existingRating.getRatingValue());
            System.out.println("Your rating will be updated.");
        }
        
        System.out.println("\nMovie: " + movie.getTitle());
        System.out.print("Enter your rating (1.0-5.0): ");
        double ratingValue = getDoubleInput(scanner);
        
        // Validate rating range
        if (ratingValue < 1.0 || ratingValue > 5.0) {
            System.out.println("\nInvalid rating! Rating must be between 1.0 and 5.0.");
            return;
        }
        
        System.out.print("Enter your review (optional, press Enter to skip): ");
        String review = scanner.nextLine().trim();
        
        if (ratingDAO.addOrUpdateRating(userId, movieId, ratingValue, review)) {
            System.out.println("\nRating saved successfully!");
            
            // Update the movie's average rating
            movieDAO.updateAverageRating(movieId);
            System.out.println("Movie's average rating has been updated.");
        } else {
            System.out.println("\nFailed to save rating. Please try again.");
        }
    }

    /**
     * Helper method to safely read integer input.
     * 
     * @param scanner Scanner object for user input
     * @return The integer value entered by the user
     */
    private int getIntInput(Scanner scanner) {
        while (true) {
            try {
                String input = scanner.nextLine().trim();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Please enter a number: ");
            }
        }
    }

    /**
     * Helper method to safely read double input.
     * 
     * @param scanner Scanner object for user input
     * @return The double value entered by the user
     */
    private double getDoubleInput(Scanner scanner) {
        while (true) {
            try {
                String input = scanner.nextLine().trim();
                return Double.parseDouble(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Please enter a number: ");
            }
        }
    }
}


