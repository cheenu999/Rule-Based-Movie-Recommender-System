package MovieRecommender.Service.Impl;

import MovieRecommender.DAO.FavouriteDAO;
import MovieRecommender.DAO.MovieDAO;
import MovieRecommender.DAO.Impl.FavouriteDAOImpl;
import MovieRecommender.DAO.Impl.MovieDAOImpl;
import MovieRecommender.Model.Favourite;
import MovieRecommender.Model.Movie;
import MovieRecommender.Service.FavouriteService;

import java.util.List;
import java.util.Scanner;

/**
 * Implementation of FavouriteService interface.
 * Handles business logic for favourite operations.
 */
public class FavouriteServiceImpl implements FavouriteService {
    private FavouriteDAO favouriteDAO;
    private MovieDAO movieDAO;

    /**
     * Constructor that initializes dependencies.
     */
    public FavouriteServiceImpl() {
        this.favouriteDAO = new FavouriteDAOImpl();
        this.movieDAO = new MovieDAOImpl();
    }

    @Override
    public void addFavourite(Scanner scanner, int userId) {
        System.out.println("\n--- ADD TO FAVOURITES ---");
        // Display all movies
        System.out.println(String.format("%-5s | %-30s | %-20s | %-20s | %-6s | %-6s",
                "ID", "Title", "Genre", "Director", "Year", "Rating"));
        System.out.println("------------------------------------------------------------------------------------------------");
        
        List<Movie> movies = movieDAO.getAllMovies();
        if (movies.isEmpty()) {
            System.out.println("No movies found in the database.");
        } else {
            for (Movie movie : movies) {
                System.out.println(String.format("%-5d | %-30s | %-20s | %-20s | %-6d | %-6.2f",
                        movie.getMovieId(), movie.getTitle(), movie.getGenre(),
                        movie.getDirector(), movie.getReleaseYear(), movie.getAverageRating()));
            }
        }
        
        System.out.print("\nEnter the movie ID to add to favourites: ");
        int movieId = getIntInput(scanner);
        
        Movie movie = movieDAO.getMovieById(movieId);
        if (movie == null) {
            System.out.println("\nMovie not found!");
            return;
        }
        
        // Check if already in favourites
        Favourite existing = favouriteDAO.read(movieId, userId);
        if (existing != null) {
            System.out.println("\nThis movie is already in your favourites!");
            return;
        }
        
        Favourite favourite = new Favourite(
            movie.getMovieId(),
            movie.getTitle(),
            movie.getGenre(),
            movie.getAverageRating(),
            userId
        );
        
        if (favouriteDAO.create(favourite)) {
            System.out.println("\nMovie added to favourites successfully!");
        } else {
            System.out.println("\nFailed to add movie to favourites. Please try again.");
        }
    }

    @Override
    public void removeFavourite(Scanner scanner, int userId) {
        System.out.println("\n--- REMOVE FROM FAVOURITES ---");
        viewFavourites(userId);
        
        System.out.print("\nEnter the movie ID to remove from favourites: ");
        int movieId = getIntInput(scanner);
        
        if (favouriteDAO.delete(movieId, userId)) {
            System.out.println("\nMovie removed from favourites successfully!");
        } else {
            System.out.println("\nFailed to remove movie from favourites. Movie may not be in your favourites.");
        }
    }

    @Override
    public void viewFavourites(int userId) {
        System.out.println("\n--- MY FAVOURITES ---");
        System.out.println(String.format("%-5s | %-30s | %-20s | %-6s",
                "ID", "Title", "Genre", "Rating"));
        System.out.println("----------------------------------------------------------------------");
        
        List<Favourite> favourites = favouriteDAO.getByUserId(userId);
        
        if (favourites.isEmpty()) {
            System.out.println("No movies in your favourites.");
        } else {
            for (Favourite favourite : favourites) {
                System.out.println(String.format("%-5d | %-30s | %-20s | %-6.2f",
                        favourite.getMovieId(), favourite.getTitle(),
                        favourite.getGenre(), favourite.getAverageRating()));
            }
        }
    }

    /**
     * Helper method to safely read integer input.
     */
    private int getIntInput(Scanner scanner) {
        while (true) {
            try {
                String input = scanner.nextLine().trim();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Please enter a number: ");
            }
        }
    }
}

