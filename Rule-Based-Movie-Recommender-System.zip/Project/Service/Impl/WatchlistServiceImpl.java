package MovieRecommender.Service.Impl;

import MovieRecommender.DAO.MovieDAO;
import MovieRecommender.DAO.WatchlistDAO;
import MovieRecommender.DAO.Impl.MovieDAOImpl;
import MovieRecommender.DAO.Impl.WatchlistDAOImpl;
import MovieRecommender.Model.Movie;
import MovieRecommender.Model.Watchlist;
import MovieRecommender.Service.WatchlistService;

import java.util.List;
import java.util.Scanner;

/**
 * Implementation of WatchlistService interface.
 * Handles business logic for watchlist operations.
 */
public class WatchlistServiceImpl implements WatchlistService {
    private WatchlistDAO watchlistDAO;
    private MovieDAO movieDAO;

    /**
     * Constructor that initializes dependencies.
     */
    public WatchlistServiceImpl() {
        this.watchlistDAO = new WatchlistDAOImpl();
        this.movieDAO = new MovieDAOImpl();
    }

    @Override
    public void addToWatchlist(Scanner scanner, int userId) {
        System.out.println("\n--- ADD TO WATCHLIST ---");
        // Display all movies
        System.out.println(String.format("%-5s | %-30s | %-20s | %-20s | %-6s | %-6s",
                "ID", "Title", "Genre", "Director", "Year", "Rating"));
        System.out.println("------------------------------------------------------------------------------------------------");
        
        List<Movie> movies = movieDAO.getAllMovies();
        if (movies.isEmpty()) {
            System.out.println("No movies found in the database.");
        } else {
            for (Movie movie : movies) {
                System.out.println(String.format("%-5d | %-30s | %-20s | %-20s | %-6d | %-6.2f",
                        movie.getMovieId(), movie.getTitle(), movie.getGenre(),
                        movie.getDirector(), movie.getReleaseYear(), movie.getAverageRating()));
            }
        }
        
        System.out.print("\nEnter the movie ID to add to watchlist: ");
        int movieId = getIntInput(scanner);
        
        Movie movie = movieDAO.getMovieById(movieId);
        if (movie == null) {
            System.out.println("\nMovie not found!");
            return;
        }
        
        // Check if already in watchlist
        Watchlist existing = watchlistDAO.read(movieId, userId);
        if (existing != null) {
            System.out.println("\nThis movie is already in your watchlist!");
            return;
        }
        
        Watchlist watchlist = new Watchlist(
            movie.getMovieId(),
            movie.getTitle(),
            movie.getGenre(),
            userId
        );
        
        if (watchlistDAO.create(watchlist)) {
            System.out.println("\nMovie added to watchlist successfully!");
        } else {
            System.out.println("\nFailed to add movie to watchlist. Please try again.");
        }
    }

    @Override
    public void removeFromWatchlist(Scanner scanner, int userId) {
        System.out.println("\n--- REMOVE FROM WATCHLIST ---");
        viewWatchlist(userId);
        
        System.out.print("\nEnter the movie ID to remove from watchlist: ");
        int movieId = getIntInput(scanner);
        
        if (watchlistDAO.delete(movieId, userId)) {
            System.out.println("\nMovie removed from watchlist successfully!");
        } else {
            System.out.println("\nFailed to remove movie from watchlist. Movie may not be in your watchlist.");
        }
    }

    @Override
    public void viewWatchlist(int userId) {
        System.out.println("\n--- MY WATCHLIST ---");
        System.out.println(String.format("%-5s | %-30s | %-20s",
                "ID", "Title", "Genre"));
        System.out.println("----------------------------------------------------------------------");
        
        List<Watchlist> watchlists = watchlistDAO.getByUserId(userId);
        
        if (watchlists.isEmpty()) {
            System.out.println("No movies in your watchlist.");
        } else {
            for (Watchlist watchlist : watchlists) {
                System.out.println(String.format("%-5d | %-30s | %-20s",
                        watchlist.getMovieId(), watchlist.getTitle(), watchlist.getGenre()));
            }
        }
    }

    /**
     * Helper method to safely read integer input.
     */
    private int getIntInput(Scanner scanner) {
        while (true) {
            try {
                String input = scanner.nextLine().trim();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Please enter a number: ");
            }
        }
    }
}

