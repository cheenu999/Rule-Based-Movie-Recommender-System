package MovieRecommender.Service.Impl;

import MovieRecommender.DAO.MovieDAO;
import MovieRecommender.DAO.RatingDAO;
import MovieRecommender.DAO.Impl.MovieDAOImpl;
import MovieRecommender.DAO.Impl.RatingDAOImpl;
import MovieRecommender.Model.Movie;
import MovieRecommender.Service.RatingService;

import java.util.List;
import java.util.Scanner;

/**
 * Implementation of RatingService interface.
 * Handles business logic for rating operations.
 */
public class RatingServiceImpl implements RatingService {
    private RatingDAO ratingDAO;
    private MovieDAO movieDAO;

    /**
     * Constructor that initializes dependencies.
     */
    public RatingServiceImpl() {
        this.ratingDAO = new RatingDAOImpl();
        this.movieDAO = new MovieDAOImpl();
    }

    @Override
    public void rateMovie(Scanner scanner, int userId) {
        System.out.println("\n--- RATE A MOVIE ---");
        // Display all movies
        System.out.println(String.format("%-5s | %-30s | %-20s | %-20s | %-6s | %-6s",
                "ID", "Title", "Genre", "Director", "Year", "Rating"));
        System.out.println("------------------------------------------------------------------------------------------------");
        
        List<Movie> movies = movieDAO.getAllMovies();
        if (movies.isEmpty()) {
            System.out.println("No movies found in the database.");
        } else {
            for (Movie movie : movies) {
                System.out.println(String.format("%-5d | %-30s | %-20s | %-20s | %-6d | %-6.2f",
                        movie.getMovieId(), movie.getTitle(), movie.getGenre(),
                        movie.getDirector(), movie.getReleaseYear(), movie.getAverageRating()));
            }
        }
        
        System.out.print("\nEnter the movie ID to rate: ");
        int movieId = getIntInput(scanner);
        
        Movie movie = movieDAO.getMovieById(movieId);
        if (movie == null) {
            System.out.println("\nMovie not found!");
            return;
        }
        
        // Check if user has already rated this movie
        MovieRecommender.Model.Rating existingRating = ratingDAO.getByUserAndMovie(userId, movieId);
        if (existingRating != null) {
            System.out.println("\nYou have already rated this movie. Your current rating: " + existingRating.getRatingValue());
            System.out.println("Your rating will be updated.");
        }
        
        System.out.println("\nMovie: " + movie.getTitle());
        System.out.print("Enter your rating (1.0-5.0): ");
        double ratingValue = getDoubleInput(scanner);
        
        // Validate rating range
        if (ratingValue < 1.0 || ratingValue > 5.0) {
            System.out.println("\nInvalid rating! Rating must be between 1.0 and 5.0.");
            return;
        }
        
        System.out.print("Enter your review (optional, press Enter to skip): ");
        String review = scanner.nextLine().trim();
        
        if (ratingDAO.addOrUpdateRating(userId, movieId, ratingValue, review)) {
            System.out.println("\nRating saved successfully!");
            
            // Update the movie's average rating
            movieDAO.updateAverageRating(movieId);
            System.out.println("Movie's average rating has been updated.");
        } else {
            System.out.println("\nFailed to save rating. Please try again.");
        }
    }

    /**
     * Helper method to safely read integer input.
     */
    private int getIntInput(Scanner scanner) {
        while (true) {
            try {
                String input = scanner.nextLine().trim();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Please enter a number: ");
            }
        }
    }

    /**
     * Helper method to safely read double input.
     */
    private double getDoubleInput(Scanner scanner) {
        while (true) {
            try {
                String input = scanner.nextLine().trim();
                return Double.parseDouble(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Please enter a number: ");
            }
        }
    }
}

