package MovieRecommender.Service.Impl;

import MovieRecommender.DAO.AdminDAO;
import MovieRecommender.DAO.MovieDAO;
import MovieRecommender.DAO.Impl.AdminDAOImpl;
import MovieRecommender.DAO.Impl.MovieDAOImpl;
import MovieRecommender.Model.Movie;
import MovieRecommender.Service.AdminService;
import MovieRecommender.Service.MovieService;

import java.util.List;
import java.util.Scanner;

/**
 * Implementation of AdminService interface.
 * Handles business logic for admin operations.
 */
public class AdminServiceImpl implements AdminService {
    private AdminDAO adminDAO;
    private MovieService movieService;

    /**
     * Constructor that initializes dependencies.
     */
    public AdminServiceImpl() {
        this.adminDAO = new AdminDAOImpl();
        this.movieService = new MovieServiceImpl();
    }

    @Override
    public int login(Scanner scanner) {
        System.out.println("\n--- ADMIN LOGIN ---");
        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Enter password: ");
        String password = scanner.nextLine().trim();

        int adminId = adminDAO.authenticate(username, password);
        
        if (adminId > 0) {
            System.out.println("\nLogin successful! Welcome, Admin " + username + "!");
            return adminId;
        } else {
            System.out.println("\nInvalid credentials! Please try again.");
            return -1;
        }
    }

    @Override
    public void showAdminMenu(Scanner scanner) {
        while (true) {
            System.out.println("\n--- ADMIN MENU ---");
            System.out.println("1. Add a new movie");
            System.out.println("2. Delete a movie");
            System.out.println("3. Update movie details");
            System.out.println("4. View all movies");
            System.out.println("5. Logout");
            System.out.print("\nEnter your choice: ");

            int choice = getIntInput(scanner);

            switch (choice) {
                case 1:
                    movieService.addMovie(scanner);
                    break;
                case 2:
                    movieService.deleteMovie(scanner);
                    break;
                case 3:
                    movieService.updateMovie(scanner);
                    break;
                case 4:
                    movieService.viewAllMovies();
                    break;
                case 5:
                    System.out.println("\nLogged out successfully!");
                    return;
                default:
                    System.out.println("\nInvalid choice! Please enter a number between 1-5.");
            }
        }
    }

    /**
     * Helper method to safely read integer input.
     */
    private int getIntInput(Scanner scanner) {
        while (true) {
            try {
                String input = scanner.nextLine().trim();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Please enter a number: ");
            }
        }
    }
}

