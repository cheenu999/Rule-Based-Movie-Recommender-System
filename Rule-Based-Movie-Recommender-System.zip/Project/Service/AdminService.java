package MovieRecommender.Service;

import java.util.Scanner;

/**
 * Service interface for admin-related business logic.
 * Defines operations for managing admin accounts and admin menu operations.
 */
public interface AdminService {
    /**
     * Handles admin login process.
     * 
     * @param scanner Scanner object for user input
     * @return Admin ID if login successful, -1 otherwise
     */
    int login(Scanner scanner);

    /**
     * Shows and handles the admin menu.
     */
    void showAdminMenu(Scanner scanner);
}

