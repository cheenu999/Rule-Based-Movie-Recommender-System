package MovieRecommender.Service;

import java.util.Scanner;

/**
 * Service interface for movie-related business logic.
 * Defines operations for managing movies, recommendations, and ratings.
 */
public interface MovieService {
    /**
     * Adds a new movie to the database.
     * 
     * @param scanner Scanner object for user input
     */
    void addMovie(Scanner scanner);

    /**
     * Deletes a movie from the database.
     * 
     * @param scanner Scanner object for user input
     */
    void deleteMovie(Scanner scanner);

    /**
     * Updates movie information in the database.
     * 
     * @param scanner Scanner object for user input
     */
    void updateMovie(Scanner scanner);

    /**
     * Displays all movies in the database.
     */
    void viewAllMovies();

    /**
     * Gets movie recommendations based on user-provided genres.
     * 
     * @param scanner Scanner object for user input
     */
    void getRecommendations(Scanner scanner);

    /**
     * Allows a user to rate a movie.
     * 
     * @param scanner Scanner object for user input
     * @param userId The ID of the user rating the movie
     */
    void rateMovie(Scanner scanner, int userId);
}



