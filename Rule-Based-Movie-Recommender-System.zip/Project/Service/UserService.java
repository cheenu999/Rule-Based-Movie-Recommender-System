package MovieRecommender.Service;

import java.util.Scanner;

/**
 * Service interface for user-related business logic.
 * Defines operations for managing user accounts and user menu operations.
 */
public interface UserService {
    /**
     * Handles user login process.
     * 
     * @param scanner Scanner object for user input
     * @return User ID if login successful, -1 otherwise
     */
    int login(Scanner scanner);

    /**
     * Shows and handles the user menu.
     * 
     * @param scanner Scanner object for user input
     * @param userId The ID of the logged-in user
     */
    void showUserMenu(Scanner scanner, int userId);
}

