package MovieRecommender.Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Utility class for managing database connections.
 * Provides a singleton-like connection management for MySQL database.
 * 
 * Note: Update the database credentials (URL, username, password) 
 * according to your MySQL configuration.
 */
public class DatabaseUtil {
    // Database connection parameters
    private static final String DB_URL = "jdbc:mysql://localhost:3306/movie_recommender";
    private static final String DB_USERNAME = "root";
    private static final String DB_PASSWORD = "10Ishi04*06"; // Change this to your MySQL password
    
    private static Connection connection = null;

    /**
     * Private constructor to prevent instantiation.
     * This class uses static methods only.
     */
    private DatabaseUtil() {
    }

    /**
     * Establishes and returns a database connection.
     * If a connection already exists and is valid, it returns the existing connection.
     * Otherwise, it creates a new connection.
     * 
     * @return Connection object to the MySQL database
     * @throws SQLException if a database access error occurs
     */
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                // Load MySQL JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");
                
                // Establish connection
                connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
                System.out.println("Database connection established successfully.");
            } catch (ClassNotFoundException e) {
                throw new SQLException("MySQL JDBC Driver not found!", e);
            } catch (SQLException e) {
                throw new SQLException("Error connecting to database: " + e.getMessage(), e);
            }
        }
        return connection;
    }

    /**
     * Closes the database connection if it exists and is open.
     * Should be called when the application is shutting down.
     * 
     * @throws SQLException if a database access error occurs
     */
    public static void closeConnection() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
            System.out.println("Database connection closed.");
        }
    }

    /**
     * Tests the database connection.
     * Useful for verifying database connectivity at application startup.
     * 
     * @return true if connection is successful, false otherwise
     */
    public static boolean testConnection() {
        try {
            Connection conn = getConnection();
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            System.err.println("Database connection test failed: " + e.getMessage());
            return false;
        }
    }
}


