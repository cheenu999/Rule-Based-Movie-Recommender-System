package MovieRecommender.Model;

/**
 * Entity class representing a User in the system.
 * This class encapsulates user information and authentication details.
 */
public class User {
    private int userId;
    private String username;
    private String password;
    private String email;
    private String registrationDate;

    /**
     * Default constructor.
     */
    public User() {
    }

    /**
     * Constructor with user properties.
     * 
     * @param userId The unique identifier for the user
     * @param username The username
     * @param password The password
     * @param email The email address
     * @param registrationDate The registration date
     */
    public User(int userId, String username, String password, String email, String registrationDate) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.email = email;
        this.registrationDate = registrationDate;
    }

    // Getters and Setters

    /**
     * Gets the user ID.
     * 
     * @return The user ID
     */
    public int getUserId() {
        return userId;
    }

    /**
     * Sets the user ID.
     * 
     * @param userId The user ID to set
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * Gets the username.
     * 
     * @return The username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username.
     * 
     * @param username The username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the password.
     * 
     * @return The password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password.
     * 
     * @param password The password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets the email.
     * 
     * @return The email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email.
     * 
     * @param email The email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the registration date.
     * 
     * @return The registration date
     */
    public String getRegistrationDate() {
        return registrationDate;
    }

    /**
     * Sets the registration date.
     * 
     * @param registrationDate The registration date to set
     */
    public void setRegistrationDate(String registrationDate) {
        this.registrationDate = registrationDate;
    }
}



