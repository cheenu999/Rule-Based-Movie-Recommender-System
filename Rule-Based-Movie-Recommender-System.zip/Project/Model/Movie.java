package MovieRecommender.Model;

/**
 * Entity class representing a Movie in the system.
 * This class encapsulates all the properties of a movie record.
 */
public class Movie {
    private int movieId;
    private String title;
    private String genre;
    private String director;
    private int releaseYear;
    private double averageRating;

    /**
     * Default constructor.
     */
    public Movie() {
    }

    /**
     * Constructor with all movie properties.
     * 
     * @param movieId The unique identifier for the movie
     * @param title The title of the movie
     * @param genre The genre of the movie
     * @param director The director of the movie
     * @param releaseYear The year the movie was released
     * @param averageRating The average rating of the movie
     */
    public Movie(int movieId, String title, String genre, String director, int releaseYear, double averageRating) {
        this.movieId = movieId;
        this.title = title;
        this.genre = genre;
        this.director = director;
        this.releaseYear = releaseYear;
        this.averageRating = averageRating;
    }

    // Getters and Setters

    /**
     * Gets the movie ID.
     * 
     * @return The movie ID
     */
    public int getMovieId() {
        return movieId;
    }

    /**
     * Sets the movie ID.
     * 
     * @param movieId The movie ID to set
     */
    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    /**
     * Gets the movie title.
     * 
     * @return The movie title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the movie title.
     * 
     * @param title The movie title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Gets the movie genre.
     * 
     * @return The movie genre
     */
    public String getGenre() {
        return genre;
    }

    /**
     * Sets the movie genre.
     * 
     * @param genre The movie genre to set
     */
    public void setGenre(String genre) {
        this.genre = genre;
    }

    /**
     * Gets the movie director.
     * 
     * @return The movie director
     */
    public String getDirector() {
        return director;
    }

    /**
     * Sets the movie director.
     * 
     * @param director The movie director to set
     */
    public void setDirector(String director) {
        this.director = director;
    }

    /**
     * Gets the release year.
     * 
     * @return The release year
     */
    public int getReleaseYear() {
        return releaseYear;
    }

    /**
     * Sets the release year.
     * 
     * @param releaseYear The release year to set
     */
    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }

    /**
     * Gets the average rating.
     * 
     * @return The average rating
     */
    public double getAverageRating() {
        return averageRating;
    }

    /**
     * Sets the average rating.
     * 
     * @param averageRating The average rating to set
     */
    public void setAverageRating(double averageRating) {
        this.averageRating = averageRating;
    }

    /**
     * Returns a string representation of the movie.
     * 
     * @return String representation of the movie
     */
    @Override
    public String toString() {
        return String.format("ID: %d | Title: %s | Genre: %s | Director: %s | Year: %d | Rating: %.2f",
                movieId, title, genre, director, releaseYear, averageRating);
    }
}



