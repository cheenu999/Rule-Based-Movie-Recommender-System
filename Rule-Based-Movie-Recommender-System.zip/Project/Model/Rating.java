package MovieRecommender.Model;

/**
 * Entity class representing a Rating in the system.
 * This class encapsulates all the properties of a rating record.
 */
public class Rating {
    private int ratingId;
    private int userId;
    private int movieId;
    private double ratingValue;
    private String review;

    /**
     * Default constructor.
     */
    public Rating() {
    }

    /**
     * Constructor with all rating properties.
     * 
     * @param ratingId The unique identifier for the rating
     * @param userId The ID of the user who gave the rating
     * @param movieId The ID of the movie being rated
     * @param ratingValue The rating value (1.0-5.0)
     * @param review The review text
     */
    public Rating(int ratingId, int userId, int movieId, double ratingValue, String review) {
        this.ratingId = ratingId;
        this.userId = userId;
        this.movieId = movieId;
        this.ratingValue = ratingValue;
        this.review = review;
    }

    // Getters and Setters

    public int getRatingId() {
        return ratingId;
    }

    public void setRatingId(int ratingId) {
        this.ratingId = ratingId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public double getRatingValue() {
        return ratingValue;
    }

    public void setRatingValue(double ratingValue) {
        this.ratingValue = ratingValue;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    @Override
    public String toString() {
        return String.format("Rating ID: %d | User ID: %d | Movie ID: %d | Rating: %.2f | Review: %s",
                ratingId, userId, movieId, ratingValue, review != null ? review : "No review");
    }
}

