package MovieRecommender.Model;

/**
 * Entity class representing an Admin in the system.
 * This class encapsulates all the properties of an admin record.
 */
public class Admin {
    private int adminId;
    private String username;
    private String password;
    private String email;
    private String fullName;
    private String role;
    private String createdAt;

    /**
     * Default constructor.
     */
    public Admin() {
    }

    /**
     * Constructor with all admin properties.
     * 
     * @param adminId The unique identifier for the admin
     * @param username The username
     * @param password The password
     * @param email The email address
     * @param fullName The full name
     * @param role The role
     * @param createdAt The creation timestamp
     */
    public Admin(int adminId, String username, String password, String email, String fullName, String role, String createdAt) {
        this.adminId = adminId;
        this.username = username;
        this.password = password;
        this.email = email;
        this.fullName = fullName;
        this.role = role;
        this.createdAt = createdAt;
    }

    // Getters and Setters

    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return String.format("ID: %d | Username: %s | Email: %s | Full Name: %s | Role: %s",
                adminId, username, email, fullName, role);
    }
}

