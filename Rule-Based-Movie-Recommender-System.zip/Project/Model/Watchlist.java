package MovieRecommender.Model;

/**
 * Entity class representing a Watchlist movie in the system.
 * This class encapsulates all the properties of a watchlist record.
 */
public class Watchlist {
    private int movieId;
    private String title;
    private String genre;
    private int userId;

    /**
     * Default constructor.
     */
    public Watchlist() {
    }

    /**
     * Constructor with all watchlist properties.
     * 
     * @param movieId The ID of the movie
     * @param title The title of the movie
     * @param genre The genre of the movie
     * @param userId The ID of the user who added it to watchlist
     */
    public Watchlist(int movieId, String title, String genre, int userId) {
        this.movieId = movieId;
        this.title = title;
        this.genre = genre;
        this.userId = userId;
    }

    // Getters and Setters

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return String.format("Movie ID: %d | Title: %s | Genre: %s | User ID: %d",
                movieId, title, genre, userId);
    }
}

