package MovieRecommender.Model;

/**
 * Entity class representing a Favourite movie in the system.
 * This class encapsulates all the properties of a favourite record.
 */
public class Favourite {
    private int movieId;
    private String title;
    private String genre;
    private double averageRating;
    private int userId;

    /**
     * Default constructor.
     */
    public Favourite() {
    }

    /**
     * Constructor with all favourite properties.
     * 
     * @param movieId The ID of the movie
     * @param title The title of the movie
     * @param genre The genre of the movie
     * @param averageRating The average rating of the movie
     * @param userId The ID of the user who favourited it
     */
    public Favourite(int movieId, String title, String genre, double averageRating, int userId) {
        this.movieId = movieId;
        this.title = title;
        this.genre = genre;
        this.averageRating = averageRating;
        this.userId = userId;
    }

    // Getters and Setters

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public double getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(double averageRating) {
        this.averageRating = averageRating;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return String.format("Movie ID: %d | Title: %s | Genre: %s | Rating: %.2f | User ID: %d",
                movieId, title, genre, averageRating, userId);
    }
}

